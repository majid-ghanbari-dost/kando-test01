# -*- coding: utf-8 -*-
"""Persian text utilities for Kandoo dataset QC.

normalize()     : unified form used for dedup keys and evidence checks
similarity()    : SequenceMatcher ratio on raw strings (call with normalized texts)
contains_phrase(): whole-token-span containment check
WORD_NUMBERS    : Persian word-numbers -> int (used for `limit` evidence)
"""
import re
from difflib import SequenceMatcher

_REPL = {
    'ي': 'ی', 'ك': 'ک', 'ة': 'ه', 'أ': 'ا', 'إ': 'ا',
    'ؤ': 'و', 'ئ': 'ی', 'ى': 'ی', 'ٱ': 'ا',
}

_DIGITS = {}
for _i, _d in enumerate('۰۱۲۳۴۵۶۷۸۹'):        # Persian digits
    _DIGITS[ord(_d)] = chr(48 + _i)
for _i, _d in enumerate('٠١٢٣٤٥٦٧٨٩'):        # Arabic-Indic digits
    _DIGITS[ord(_d)] = chr(48 + _i)

_PUNCT = {'؟': '?', '،': ',', '؛': ';', '\u200f': '', '\u200e': '', '\ufeff': ''}


def normalize(text):
    """Unify Arabic char variants, map all digit shapes to ASCII, drop ZWNJ/RLM/LRM,
    collapse whitespace and unify sentence punctuation."""
    if not text:
        return ''
    t = str(text)
    for k, v in _REPL.items():
        t = t.replace(k, v)
    t = t.translate(_DIGITS)
    t = t.replace('\u200c', '')
    for k, v in _PUNCT.items():
        t = t.replace(k, v)
    t = re.sub(r'\s+', ' ', t)
    return t.strip()


def similarity(a, b):
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


_W = 'A-Za-z0-9\u0600-\u06FF\u0750-\u077F'


def contains_phrase(hay, needle):
    """True if `needle` appears in `hay` as a whole token span (both must be normalized)."""
    if not needle:
        return False
    pat = r'(?<![%s])%s(?![%s])' % (_W, re.escape(needle), _W)
    return re.search(pat, hay) is not None


WORD_NUMBERS = {
    'یک': 1, 'دو': 2, 'سه': 3, 'چهار': 4, 'پنج': 5, 'شش': 6, 'شیش': 6,
    'هفت': 7, 'هشت': 8, 'نه': 9, 'ده': 10, 'یازده': 11, 'دوازده': 12,
    'پانزده': 15, 'بیست': 20, 'سی': 30, 'پنجاه': 50, 'صد': 100,
}
