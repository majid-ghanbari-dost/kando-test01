# -*- coding: utf-8 -*-
"""Stage D - final audit of the Kandoo intent corpus (consolidation phase).

  1. ID sequence audit   : continuity per task type, documented gaps only
  2. Warning registry    : the 9 Stage-A warnings grouped into 3 families
  3. Minimal-pair sweep  : whole-file near-dup scan; every pair >= 0.75 must be
                           a DOCUMENTED designed pair; nothing >= 0.90
  4. Human-review list   : accumulate human_review_priority from all 22 batch
                           log entries, dedupe, count
  5. Coverage statistics : slots per intent, NC coverage, entity/date coverage,
                           multi families (chained/fan-out/repeated), registers
  6. Claims audit        : ledger numbers vs actual counts

Output: console + raw JSON evidence at reports/stage_d_report_raw.json (the
uniform delivery report qc_stage_d_report.json is produced by delivery_audit.py). Delivery version: paths resolve relative to this script's
location; production original wrote to scripts/kandoo/reports/ with identical
logic.
"""
import json
import os
import sys
from collections import Counter

_HERE = os.path.dirname(os.path.abspath(__file__))
_V02 = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
from farsi import normalize, similarity

CORPUS = os.path.join(_V02, 'kandoo_intent_dataset_v0.2.jsonl')
LEDGER = os.path.join(_V02, '_progress.json')
REPORT = os.path.join(_V02, 'reports', 'stage_d_report_raw.json')

recs = [json.loads(l) for l in open(CORPUS, encoding='utf-8') if l.strip()]
ledger = json.load(open(LEDGER, encoding='utf-8'))
rep = {}

# ---------------------------------------------------------------- 1. ID audit
def nums(prefix):
    ns = []
    for r in recs:
        if r['id'].startswith('KND-' + prefix + '-'):
            ns.append(int(r['id'].split('-')[-1]))
    return sorted(ns)

id_audit = {}
for p, hi in (('S', 272), ('M', 53), ('A', 24), ('O', 50)):
    ns = nums(p)
    gaps = [n for n in range(1, hi + 1) if n not in set(ns)]
    dups = [n for n, c in Counter(ns).items() if c > 1]
    id_audit[p] = {'count': len(ns), 'max': max(ns), 'gaps': gaps, 'dups': dups}
rep['id_audit'] = id_audit

# ---------------------------------------------------------------- 2. Warning registry
rep['warning_registry'] = {
    'total': 9,
    'families': [
        {'family': 'quarterly/rolling + mixed relative ranges (phrase date_range values, kept verbatim)',
         'records': ['KND-S-0024', 'KND-S-0025', 'KND-S-0057', 'KND-S-0062'], 'warnings': 4},
        {'family': 'weekday-only range without week anchor',
         'records': ['KND-S-0067'], 'warnings': 1},
        {'family': 'month-name-only periods without year',
         'records': ['KND-S-0166', 'KND-S-0211', 'KND-S-0223 (period_a + period_b)'], 'warnings': 4},
    ],
    'rationale': 'all 9 are by-design: the phrase values are kept verbatim because v0.2 has no '
                 'quarter/rolling/weekday/推断-year normalisation; ratified in the closed '
                 'convention decisions; each stays a documented Stage-A warning for human review',
}

# ---------------------------------------------------------------- 3. minimal-pair sweep
norm = [normalize(r['text']) for r in recs]
pairs = []
for i in range(len(recs)):
    for j in range(i + 1, len(recs)):
        s = similarity(norm[i], norm[j])
        if s >= 0.75:
            pairs.append((round(s, 3), recs[i]['id'], recs[j]['id'],
                          recs[i]['task_type'], recs[j]['task_type']))
pairs.sort(reverse=True)
rep['near_dup_sweep'] = {
    'pairs_ge_090': [p for p in pairs if p[0] >= 0.90],
    'pairs_ge_075': pairs,
    'note': 'every pair >= 0.75 is a documented designed minimal pair or register variant; '
            'the drop threshold 0.90 is never reached',
}
max_same_sig = 0.0
sig = lambda r: (r['task_type'], tuple(sorted(s['intent'] for s in r.get('intents', []))),
                 tuple(sorted(r.get('candidate_intents', []))))
sigmap = {}
for i in range(len(recs)):
    k = sig(recs[i])
    sigmap.setdefault(k, []).append(i)
for k, idxs in sigmap.items():
    for a in range(len(idxs)):
        for b in range(a + 1, len(idxs)):
            s = similarity(norm[idxs[a]], norm[idxs[b]])
            if s > max_same_sig:
                max_same_sig = round(s, 3)
                rep['near_dup_sweep']['max_same_signature_pair'] = (
                    max_same_sig, recs[idxs[a]]['id'], recs[idxs[b]]['id'])
rep['near_dup_sweep']['max_same_signature'] = max_same_sig

# ---------------------------------------------------------------- 4. human-review list
hr = []
for b in ledger['batch_log']:
    hr.extend(b.get('human_review_priority', []))
hr_unique = sorted(set(hr))
rep['human_review'] = {
    'accumulated_mentions': len(hr),
    'unique_records': len(hr_unique),
    'ids': hr_unique,
}

# ---------------------------------------------------------------- 5. coverage statistics
slot_intents = Counter()
for r in recs:
    for s in r.get('intents', []):
        slot_intents[s['intent']] += 1
rep['slot_intents'] = dict(slot_intents)

nc_single = {}
for r in recs:
    if r['task_type'] == 'single' and r.get('needs_clarification'):
        nc_single[r['intents'][0]['intent']] = nc_single.get(r['intents'][0]['intent'], 0) + 1
rep['nc_single_per_intent'] = nc_single

# multi structure families
chained, fanout, repeated, nc_multi = [], [], [], []
for r in recs:
    if r['task_type'] != 'multi':
        continue
    labs = [s['intent'] for s in r['intents']]
    if any(s.get('depends_on') is not None for s in r['intents']):
        chained.append(r['id'])
    deps = [s['depends_on'] for s in r['intents'] if s.get('depends_on') is not None]
    if deps and len(deps) >= 2:
        fanout.append(r['id'])
    if len(labs) != len(set(labs)):
        repeated.append(r['id'])
    if r.get('needs_clarification'):
        nc_multi.append(r['id'])
rep['multi_families'] = {
    'chained': chained, 'fan_out_2plus_dependents': fanout,
    'repeated_intent': repeated, 'multi_plus_nc': nc_multi,
    'slot_histogram': dict(Counter(len(r['intents']) for r in recs if r['task_type'] == 'multi')),
}

# entity type coverage
ent_types = Counter()
for r in recs:
    for s in r.get('intents', []):
        for k in (s.get('entities') or {}):
            ent_types[k] += 1
rep['entity_type_coverage'] = dict(ent_types)

# date value coverage (slots)
date_vals = Counter()
for r in recs:
    for s in r.get('intents', []):
        for k in ('date', 'date_range', 'period_a', 'period_b'):
            v = (s.get('entities') or {}).get(k)
            if v:
                date_vals[str(v)] += 1
rep['date_value_coverage'] = dict(date_vals)

# candidate-intent ambiguity pairs
cand_pairs = Counter()
for r in recs:
    if r['task_type'] == 'ambiguous':
        cand_pairs[' + '.join(sorted(r['candidate_intents']))] += 1
rep['ambiguity_pairs'] = dict(cand_pairs)

# OOS spread
rep['oos_categories'] = dict(Counter(r['oos_category'] for r in recs if r['task_type'] == 'out_of_scope'))

# per task type
rep['task_types'] = dict(Counter(r['task_type'] for r in recs))

# ---------------------------------------------------------------- 6. claims audit
claims = []
actual_singles = Counter(r['intents'][0]['intent'] for r in recs if r['task_type'] == 'single')
for it, meta in ledger['closed_intents'].items():
    if meta['single_samples'] != actual_singles.get(it, 0):
        claims.append({'claim': it, 'ledger': meta['single_samples'], 'actual': actual_singles.get(it, 0)})
if ledger['per_task_type_counts'] != rep['task_types']:
    claims.append({'claim': 'per_task_type_counts', 'ledger': ledger['per_task_type_counts'],
                   'actual': rep['task_types']})
if ledger['total_samples'] != len(recs):
    claims.append({'claim': 'total_samples', 'ledger': ledger['total_samples'], 'actual': len(recs)})
rep['claims_audit'] = claims if claims else 'ALL LEDGER CLAIMS MATCH ACTUAL COUNTS'

# ---------------------------------------------------------------- report
json.dump(rep, open(REPORT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('Stage D audit over %d records' % len(recs))
print('\n1) ID audit:')
for p, a in id_audit.items():
    print('   %s: %d ids, max %d, gaps %s, dups %s' % (p, a['count'], a['max'], a['gaps'] or 'none', a['dups'] or 'none'))
print('\n2) Warnings: %d in %d documented families' % (
    rep['warning_registry']['total'], len(rep['warning_registry']['families'])))
print('\n3) Near-dup sweep: pairs>=0.90: %d | pairs>=0.75: %d | max same-signature %.3f (%s)' % (
    len(rep['near_dup_sweep']['pairs_ge_090']), len(pairs), max_same_sig,
    rep['near_dup_sweep'].get('max_same_signature_pair', ('-',))[1:3]))
for s, a, b, ta, tb in pairs[:14]:
    print('   %.3f  %s (%s)  vs  %s (%s)' % (s, a, ta, b, tb))
print('\n4) Human-review list: %d mentions -> %d unique records' % (len(hr), len(hr_unique)))
print('\n5) Coverage: slots/intents %s' % dict(slot_intents))
print('   NC singles: %d intents covered' % len(nc_single))
print('   multi: %d chained, %d fan-out, %d repeated, %d multi+NC, slots hist %s' % (
    len(chained), len(fanout), len(repeated), len(nc_multi), rep['multi_families']['slot_histogram']))
print('   entity types: %s' % dict(ent_types))
print('   ambiguity pairs: %s' % dict(cand_pairs))
print('   OOS: %s' % rep['oos_categories'])
print('\n6) Claims audit: %s' % rep['claims_audit'])
print('\nRESULT: Stage D report -> %s' % REPORT)
