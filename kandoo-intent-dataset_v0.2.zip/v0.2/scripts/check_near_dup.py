# -*- coding: utf-8 -*-
"""Near-dup sanity check of a batch against the delivered corpus (Stage B mimic).
Usage (from the v0.2 delivery root):
    python3 scripts/check_near_dup.py batches/batch_010.jsonl
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from farsi import normalize, similarity

_HERE = os.path.dirname(os.path.abspath(__file__))
_V02 = os.path.dirname(_HERE)
BATCH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(_V02, 'batches', 'batch_010.jsonl')
CORPUS = os.path.join(_V02, 'kandoo_intent_dataset_v0.2.jsonl')

new = [json.loads(l) for l in open(BATCH, encoding='utf-8') if l.strip()]
corpus = [json.loads(l) for l in open(CORPUS, encoding='utf-8') if l.strip()]
corpus = [r for r in corpus if r['id'] not in {x['id'] for x in new}]

worst = []
for a in new:
    na = normalize(a['text'])
    for b in corpus:
        nb = normalize(b['text'])
        s = similarity(na, nb)
        if s >= 0.55:
            worst.append((round(s, 3), a['id'], b['id'], a['text'], b['text']))

worst.sort(reverse=True)
if not worst:
    print('OK: no pair >= 0.55')
for s, ia, ib, ta, tb in worst[:12]:
    print('%.3f  %s vs %s\n      new : %s\n      old : %s' % (s, ia, ib, ta, tb))
