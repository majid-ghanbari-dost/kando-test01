# Kandoo Intent Dataset v0.2 — Auditable Delivery

 Persian POS cashier-assistant intent dataset — **398 records / 12 intents / 22 production batches / 4 QC stages** — frozen 2026-11-11.

This folder is the **real, reproducible delivery** of everything claimed in the v0.2 mission report: the final JSONL extracted from the actual working file (md5 `f326cf9d3807139ee1ce44dd9cdc1234`, byte-identical), all 22 batch files, the production ledger, the QC scripts re-runnable on the final file, and the full QC evidence chain (Stages A–D re-executed on the delivered file on the date recorded inside each report).

---

## 1. Folder structure

```text
kandoo-intent-dataset/v0.2/
├── README.md                            ← this file
├── kandoo_intent_dataset_v0.2.jsonl     ← FINAL dataset (398 records, extracted from the real working file)
├── DATASET_DOCUMENTATION.md             ← full Persian documentation (12 intents, record types, entities, conventions, QC, minimal pairs, gaps)
├── _progress.json                       ← production ledger (“دفتر کل تولید”): 22-batch history, 44 closed convention decisions, 4 QC incidents, per-intent gaps
├── MANIFEST-SHA256.txt                  ← SHA-256 of every delivered file
├── reports/
│   ├── Kandoo_Dataset_Delivery_Audit_v0.2.md   ← mandatory 14-section delivery audit report (VERIFIED / NOT VERIFIED / FAILED / NOT APPLICABLE per claim)
│   ├── qc_stage_a_report.json           ← Stage A structural validation (re-executed)
│   ├── qc_stage_b_report.json           ← Stage B duplication / near-duplicate sweep (re-executed on frozen file + historical per-batch evidence)
│   ├── qc_stage_c_report.json           ← Stage C semantic pass (re-executed; 17 flags → human review) — uniform wrapper
│   ├── qc_stage_d_report.json           ← Stage D independent audit (re-executed) — uniform wrapper
│   ├── stage_c_report_raw.json          ← raw Stage C evidence (written directly by stage_c_semantic_pass.py)
│   ├── stage_d_report_raw.json          ← raw Stage D evidence (written directly by stage_d_audit.py)
│   ├── dataset_statistics.json          ← every statistic recomputed from the delivered file
│   ├── human_review_priority.json       ← 144-record priority list + reasons (+ supplementary finding)
│   └── delivery_audit.json              ← master evidence file produced by scripts/delivery_audit.py
├── batches/
│   └── batch_001.jsonl … batch_022.jsonl   ← 22 production batches; concatenation in filename order reproduces the final file byte-exactly (verified)
├── rejected_drafts/
│   └── batch_007_draft_v0_REJECTED.jsonl   ← rejected production draft (QC incident #1) — NOT part of the final dataset
├── scripts/                             ← real QC toolchain (see §3 for name mapping)
│   ├── validate_batch.py
│   ├── check_near_dup.py
│   ├── stage_c_semantic_pass.py
│   ├── stage_d_audit.py
│   ├── delivery_audit.py
│   ├── farsi.py
│   └── historical_stage_b_preflight.json
└── schemas/
    └── record_schema.json               ← JSON Schema (draft-07) of the record; all 398 records validate against it
```

## 2. Provenance (why these files are the real artifacts)

- `kandoo_intent_dataset_v0.2.jsonl` is a **byte-identical copy** of the production working file (`kandoo_intent_dataset_working.jsonl`, md5 `f326cf9d3807139ee1ce44dd9cdc1234` — recorded in `_progress.json → deliverables.md5_working_equals_final`). No record was added, removed or rewritten for delivery.
- The 22 batch files are the actual per-batch outputs. `python3 -c "cat batches/batch_*.jsonl > /tmp/x && cmp /tmp/x kandoo_intent_dataset_v0.2.jsonl"` succeeds (byte-exact concatenation in filename order).
- `_progress.json` is the production ledger as of freeze; it contains the 22-batch log, 44 closed convention decisions, 4 QC incidents (incl. the false-claim incident #4 that batch 022 repaired), documented ID gap `KND-A-0008`, and the v0.3 recommendation list.
- The QC reports in `reports/` were **re-executed on the delivered file** on the timestamp recorded inside each report (`executed_at_utc`). They are not retro-dated historical artifacts; the historical per-batch evidence is embedded inside `qc_stage_b_report.json → historical_evidence`.

## 3. Script name mapping (real names kept)

The delivery contract suggested generic names; the real production names are kept unchanged:

| Contract name | Real delivered name | Role |
|---|---|---|
| `validate_batch.py` | `scripts/validate_batch.py` | Stage A — structural validation of every record (whitelists, shapes, duplicates, clarification rules, depends_on syntax) |
| `near_duplicate_check.py` | `scripts/check_near_dup.py` | per-batch near-duplicate sweep against the corpus (Stage B mimic) |
| `stage_c_review.py` | `scripts/stage_c_semantic_pass.py` | Stage C — whole-file semantic convention pass (entity evidence, lexicon families, NC consistency, depends_on legality, M-0024 rule) |
| `stage_d_audit.py` | `scripts/stage_d_audit.py` | Stage D — ID audit, warning registry, minimal-pair sweep, coverage statistics, ledger claims audit |
| `farsi_normalization.py` | `scripts/farsi.py` | Persian normalization + similarity + phrase-containment utilities used by all checks |
| (runner) | `scripts/delivery_audit.py` | one-shot re-execution of Stages A–D on the delivered file + claims verification + multi-intent audit; writes all report JSONs |

Not delivered (not needed to re-run QC on the final file, remain in the production repository history): the section authoring pipeline (`qc.py`, `schema.py`, `store.py`, `sec0*.py`) and the 22 `make_batch_*.py` generators.

**Adaptation disclosure:** the delivered scripts are the production scripts with only their path constants changed from absolute sandbox paths (`/home/z/my-project/...`) to paths relative to this folder, so they run on a clean clone. The checking logic is unchanged. `historical_stage_b_preflight.json` is a verbatim copy of the production Stage-B preflight ledger (`scripts/kandoo/data/ledger.json`).

## 4. How to re-run every check (from this `v0.2/` folder)

```bash
# 1. Full audit suite (runs Stages A, C, D via subprocess, Stage B in-process,
#    verifies all 25 claims, multi-intent audit, statistics, human-review list;
#    rewrites reports/*.json):
python3 scripts/delivery_audit.py

# 2. Stage A alone (structural validation, exit code 0 = PASS):
python3 scripts/validate_batch.py kandoo_intent_dataset_v0.2.jsonl

# 3. Stage C alone (semantic pass; refreshes the RAW evidence reports/stage_c_report_raw.json):
python3 scripts/stage_c_semantic_pass.py

# 4. Stage D alone (independent audit; refreshes the RAW evidence reports/stage_d_report_raw.json):
python3 scripts/stage_d_audit.py

# 5. Per-batch near-duplicate check (any batch):
python3 scripts/check_near_dup.py batches/batch_022.jsonl

# 6. Batch-concatenation integrity:
cat batches/batch_*.jsonl > /tmp/concat.jsonl && cmp /tmp/concat.jsonl kandoo_intent_dataset_v0.2.jsonl && echo CONCAT_OK

# 7. JSON Schema validation of every record (optional, needs `pip install jsonschema`):
python3 - <<'EOF'
import json, jsonschema
schema = json.load(open('schemas/record_schema.json'))
recs = [json.loads(l) for l in open('kandoo_intent_dataset_v0.2.jsonl', encoding='utf-8') if l.strip()]
[jsonschema.validate(r, schema) for r in recs]
print('SCHEMA_OK', len(recs))
EOF

# 8. Manifest verification:
sha256sum -c MANIFEST-SHA256.txt
```

> **Note on manifest vs re-runs:** `delivery_audit.py` embeds `executed_at_utc` timestamps in the 7 generated report files, so **re-running it legitimately changes those 7 hashes**. The manifest pins the *delivered snapshot*. Verify the manifest **before** re-running the audit (or expect exactly the 7 report files to differ afterwards: `qc_stage_a/b/c/d_report.json`, `dataset_statistics.json`, `human_review_priority.json`, `delivery_audit.json`).

Requirements: Python ≥ 3.8, standard library only (check 7 additionally needs `jsonschema`).

## 5. Expected results (re-executed 2026-11-11)

| Check | Result |
|---|---|
| Stage A structural | **PASS** — 398 records, 0 errors, 9 warnings (all documented intentional phrase-valued dates, 3 families) |
| Stage B duplication | **PASS** — 0 exact duplicates, 0 pairs ≥ 0.90; 31 pairs in [0.75, 0.90) registered as designed minimal pairs / register variants (human sign-off pending) |
| Stage C semantic | automated checks **PASS**; 17 flags queued for human review (adjudicated by-design in the consolidation pass — documented in `_progress.json`) |
| Stage D audit | **PASS** — all ledger claims match actual counts; ID gap `KND-A-0008` documented; max same-signature similarity 0.847 < 0.90 |
| Claims verification | **25/25 MATCH** (all 14 mission-report numbers + 11 ledger cross-checks) |
| Multi-intent & dependency audit | **PASS** — 43×2-slot, 8×3-slot, 1×4-slot, 1×5-slot; 12 chains; 3 multi-dependent; 19 repeated-intent; 1 multi+NC (KND-M-0053); every `depends_on` points to a previous slot; 0 cycles; 0 M-0024 violations |
| Batch concatenation | byte-exact reproduction of the final file |

See `reports/Kandoo_Dataset_Delivery_Audit_v0.2.md` for the full 14-section audit with per-claim status labels.

## 6. Known gaps and limits (honesty section)

- **All 398 records are `seed_needs_review`** — the dataset is NOT human-verified. 144 records are on the production priority list (`reports/human_review_priority.json`); the audit additionally found 10 stage-C-flagged records that are **not** on that list (listed in the same file under `supplementary_stage_c_flagged_not_in_priority`) — recommended for inclusion in the human pass.
- The 31 near-duplicate pairs ≥ 0.75 carry a documented *designed-pair* adjudication; final sign-off is human.
- Intent slot counts are uneven by design (quality over quantity; per-intent `gap_reason` fields in `_progress.json → closed_intents`).
- v0.2 has no year-inference for month-name periods, no quarter/rolling-window normalization (the 9 documented warnings), exactly 1 experimental pinglish sample, and 1 documented unused ID (`KND-A-0008`).
