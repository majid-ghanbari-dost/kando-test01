#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stage A - Structural validation for the Kandoo Intent Dataset v0.2 working file.

Usage (from the v0.2 delivery root):
    python3 scripts/validate_batch.py [path_to_jsonl]

Default path: kandoo_intent_dataset_v0.2.jsonl (delivery root, resolved relative to
this script; production original pointed at the working file with identical
content, md5 f326cf9d3807139ee1ce44dd9cdc1234).
Exit code: 0 = PASS (no structural errors), 1 = FAIL.
"""
import json
import os
import re
import sys
from collections import Counter

_HERE = os.path.dirname(os.path.abspath(__file__))
_V02 = os.path.dirname(_HERE)
DEFAULT_PATH = os.path.join(_V02, "kandoo_intent_dataset_v0.2.jsonl")

INTENT_WHITELIST = {
    "GET_SALES_REPORT", "GET_PRODUCT_SALES", "GET_PRODUCT_STOCK", "GET_LOW_STOCK",
    "SEARCH_PRODUCT", "GET_LAST_INVOICE", "SEARCH_INVOICE", "GET_CUSTOMER_INFO",
    "SEARCH_CUSTOMER", "GET_TOP_PRODUCTS", "GET_SALES_COMPARISON", "GET_DAILY_SUMMARY",
}
TASK_TYPES = {"single", "multi", "ambiguous", "out_of_scope"}
ENTITY_TYPES = {
    "product_name", "customer_name", "customer_id", "phone", "invoice_number",
    "date", "date_range", "period_a", "period_b", "limit",
}
RELATIVE_DATES = {
    "today", "yesterday", "this_week", "last_week",
    "this_month", "last_month", "this_year", "last_year",
}
OOS_CATEGORIES = {
    "weather", "news", "entertainment", "general_knowledge", "tutoring",
    "creative_writing", "finance_crypto", "general_advice", "car_repair",
    "design", "unsupported_business_feature", "chitchat",
}
REVIEW_STATUSES = {"seed_needs_review", "auto_validated", "human_verified", "rejected"}
REQUIRED_FIELDS = [
    "id", "text", "task_type", "intents", "candidate_intents",
    "needs_clarification", "clarification_reason", "clarification_question", "review_status",
]
ALLOWED_FIELDS = set(REQUIRED_FIELDS)
ALLOWED_INTENT_FIELDS = {"intent", "entities", "depends_on"}
ID_PATTERN = re.compile(r"^KND-(S|M|A|O)-\d{4}$")
DIGIT_PATTERN = re.compile(r"[0-9۰-۹]")


def validate(path):
    errors, warnings = [], []
    seen_ids, seen_texts = set(), set()
    intent_counts, task_counts, oos_counts = Counter(), Counter(), Counter()
    n = 0

    with open(path, encoding="utf-8") as f:
        for lineno, raw in enumerate(f, 1):
            raw = raw.strip()
            if not raw:
                continue
            n += 1
            try:
                rec = json.loads(raw)
            except json.JSONDecodeError as exc:
                errors.append(f"line {lineno}: invalid JSON -> {exc}")
                continue

            if not isinstance(rec, dict):
                errors.append(f"line {lineno}: top-level JSON value must be an object, got {type(rec).__name__}")
                continue

            rid = str(rec.get("id", f"<line {lineno}>"))

            # required fields
            for field in REQUIRED_FIELDS:
                if field not in rec:
                    errors.append(f"{rid}: missing required field '{field}'")

            # task_type is read early: field permissions depend on it
            task_type = rec.get("task_type")

            # id format & uniqueness
            if not ID_PATTERN.match(str(rec.get("id", ""))):
                warnings.append(f"{rid}: id does not match pattern KND-[S|M|A|O]-NNNN")
            if rid in seen_ids:
                errors.append(f"{rid}: duplicate id")
            seen_ids.add(rid)

            # text
            text = str(rec.get("text", "")).strip()
            if not text:
                errors.append(f"{rid}: empty text")
            norm_text = re.sub(r"\s+", " ", text)
            if norm_text in seen_texts:
                errors.append(f"{rid}: duplicate text (exact match after whitespace normalisation)")
            seen_texts.add(norm_text)

            # task_type validity & counts
            if task_type not in TASK_TYPES:
                errors.append(f"{rid}: invalid task_type '{task_type}'")
            else:
                task_counts[task_type] += 1

            # unknown top-level fields (oos_category is reserved for out_of_scope)
            allowed_fields = ALLOWED_FIELDS | ({"oos_category"} if task_type == "out_of_scope" else set())
            for field in rec:
                if field not in allowed_fields:
                    errors.append(f"{rid}: unknown top-level field '{field}' (allowed: {sorted(allowed_fields)})")

            # out_of_scope-specific rules
            if task_type == "out_of_scope":
                if rec.get("oos_category") not in OOS_CATEGORIES:
                    errors.append(f"{rid}: out_of_scope sample needs a valid 'oos_category' from the whitelist (got {rec.get('oos_category')!r})")
                else:
                    oos_counts[rec["oos_category"]] += 1
                if rec.get("candidate_intents"):
                    errors.append(f"{rid}: out_of_scope sample must have candidate_intents == []")
                if rec.get("needs_clarification"):
                    errors.append(f"{rid}: out_of_scope sample must have needs_clarification=false")
                if rec.get("clarification_reason") or rec.get("clarification_question"):
                    warnings.append(f"{rid}: out_of_scope sample carries clarification fields while needs_clarification=false")

            intents = rec.get("intents") or []
            if not isinstance(intents, list):
                errors.append(f"{rid}: 'intents' must be a list, got {type(intents).__name__}")
                intents = []
            if task_type == "out_of_scope" and intents:
                errors.append(f"{rid}: out_of_scope sample must have intents == []")
            if task_type in ("single", "multi") and not intents:
                errors.append(f"{rid}: {task_type} sample needs at least one intent")

            # per-intent checks
            for i, item in enumerate(intents):
                if not isinstance(item, dict):
                    errors.append(f"{rid}: intents[{i}] must be an object, got {type(item).__name__}")
                    continue
                for key in item:
                    if key not in ALLOWED_INTENT_FIELDS:
                        errors.append(f"{rid}: intents[{i}] has unknown field '{key}' (allowed: intent/entities/depends_on)")
                name = item.get("intent")
                if name not in INTENT_WHITELIST:
                    errors.append(f"{rid}: intents[{i}] '{name}' not in whitelist")
                else:
                    intent_counts[name] += 1
                entities = item.get("entities") or {}
                for key, value in entities.items():
                    if key not in ENTITY_TYPES:
                        errors.append(f"{rid}: intents[{i}] entity key '{key}' not allowed")
                    if key in ("date", "date_range", "period_a", "period_b"):
                        sval = str(value)
                        if sval not in RELATIVE_DATES and not DIGIT_PATTERN.search(sval):
                            warnings.append(
                                f"{rid}: intents[{i}] {key}='{sval}' is neither a standard "
                                f"relative value nor contains a digit (specific date)"
                            )
                depends_on = item.get("depends_on")
                if depends_on is not None:
                    if not isinstance(depends_on, int) or not (0 <= depends_on < len(intents)) or depends_on == i:
                        errors.append(f"{rid}: intents[{i}] depends_on is malformed")
                if task_type == "single" and depends_on is not None:
                    errors.append(f"{rid}: single sample must have depends_on=null")

            # structural rules per task_type
            if task_type == "single" and len(intents) != 1:
                errors.append(f"{rid}: single sample must have exactly one intent")
            if task_type == "multi" and len(intents) < 2:
                errors.append(f"{rid}: multi sample must have at least two intents")

            # clarification fields
            needs_clarification = rec.get("needs_clarification")
            if not isinstance(needs_clarification, bool):
                errors.append(f"{rid}: needs_clarification must be a boolean")
                needs_clarification = None
            if needs_clarification:
                if not rec.get("clarification_reason"):
                    warnings.append(f"{rid}: needs_clarification=true but clarification_reason is empty")
                if not rec.get("clarification_question"):
                    warnings.append(f"{rid}: needs_clarification=true but clarification_question is empty")
            elif needs_clarification is False:
                if rec.get("clarification_reason") or rec.get("clarification_question"):
                    warnings.append(f"{rid}: clarification fields set while needs_clarification=false")

            # candidate intents
            candidates = rec.get("candidate_intents") or []
            if task_type in ("single", "multi") and candidates:
                errors.append(f"{rid}: candidate_intents must be empty for task_type '{task_type}' (reserved for ambiguous)")
            for cand in candidates:
                if cand not in INTENT_WHITELIST:
                    errors.append(f"{rid}: candidate intent '{cand}' not in whitelist")
            if task_type == "ambiguous":
                if intents:
                    errors.append(f"{rid}: ambiguous sample must have intents == [] (use candidate_intents)")
                if len(candidates) < 2:
                    errors.append(f"{rid}: ambiguous sample needs >= 2 candidate_intents")
                if needs_clarification is not True:
                    errors.append(f"{rid}: ambiguous sample must have needs_clarification=true")
            if task_type == "out_of_scope" and needs_clarification:
                warnings.append(f"{rid}: out_of_scope with needs_clarification=true - verify this is intended")

            # review status
            if rec.get("review_status") not in REVIEW_STATUSES:
                errors.append(f"{rid}: invalid review_status '{rec.get('review_status')}'")

    print(f"file            : {path}")
    print(f"total samples   : {n}")
    print(f"task_type counts: {dict(task_counts)}")
    print(f"intent counts   : {dict(intent_counts) if intent_counts else '(none)'}")
    print(f"oos categories  : {dict(oos_counts) if oos_counts else '(none)'}")
    print(f"errors          : {len(errors)}")
    for msg in errors:
        print(f"  ERROR: {msg}")
    print(f"warnings        : {len(warnings)}")
    for msg in warnings:
        print(f"  WARN : {msg}")
    print("RESULT          : " + ("PASS (Stage A)" if not errors else "FAIL"))
    return 0 if not errors else 1


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PATH
    sys.exit(validate(target))
