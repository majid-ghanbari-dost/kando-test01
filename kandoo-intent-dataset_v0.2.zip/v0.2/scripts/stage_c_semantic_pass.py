# -*- coding: utf-8 -*-
"""Stage C - full semantic pass over the whole Kandoo intent corpus (consolidation phase).

Automated re-verification of semantic conventions on ALL records:
  1. lexicon families      : حساب/صورتحساب/گزارش/خلاصه/موجودی/درآمد/سود/پرفروش|کم‌فروش/فاکتور
  2. entity text-evidence  : every entity value must be evidenced in text
                             (standard date tokens via synonym map, digit values token-wise,
                              non-standard phrases only if in the documented warning registry,
                              product/customer names verbatim or in canonical_value_exceptions)
  3. digit conventions     : customer_id/phone/invoice_number/limit hold Latin digits
  4. NC consistency        : needs_clarification <-> reason+question, per task type
  5. depends_on legality   : null for singles; valid index; chained slot must not carry the
                             chained entity type (explicit entity => independent, M-0024 rule)
  6. structural invariants : intent/OOS whitelists, ambiguous shape, OOS shape,
                             honorific-free customer_name, review_status, unique ids/texts

Everything suspicious is FLAGGED for human review (this stage does not auto-edit records).
Output: console report + raw JSON evidence at reports/stage_c_report_raw.json
(the uniform delivery report qc_stage_c_report.json is produced by delivery_audit.py,
which wraps this raw output with execution metadata)
(delivery version: paths resolve relative to this script's location; the
production original wrote to scripts/kandoo/reports/ with identical logic).
"""
import json
import os
import re
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_V02 = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
from farsi import normalize, contains_phrase, WORD_NUMBERS

CORPUS = os.path.join(_V02, 'kandoo_intent_dataset_v0.2.jsonl')
LEDGER = os.path.join(_V02, '_progress.json')
REPORT = os.path.join(_V02, 'reports', 'stage_c_report_raw.json')

INTENTS = {'GET_SALES_REPORT', 'GET_PRODUCT_SALES', 'GET_PRODUCT_STOCK', 'GET_LOW_STOCK',
           'SEARCH_PRODUCT', 'GET_LAST_INVOICE', 'SEARCH_INVOICE', 'GET_CUSTOMER_INFO',
           'SEARCH_CUSTOMER', 'GET_TOP_PRODUCTS', 'GET_SALES_COMPARISON', 'GET_DAILY_SUMMARY'}
OOS_CATS = {'weather', 'chitchat', 'unsupported_business_feature', 'finance_crypto',
            'creative_writing', 'news', 'general_knowledge', 'design', 'entertainment',
            'car_repair', 'tutoring', 'general_advice'}
STD_DATES = {'today', 'yesterday', 'this_week', 'last_week', 'this_month', 'last_month',
             'this_year', 'last_year'}
DATE_FIELDS = {'date', 'date_range', 'period_a', 'period_b'}

# documented synonym evidence for the 8 standard relative tokens
# (includes ratified normalisation edges: از صبح تا الان -> today, از اول هفته تا الان -> this_week,
#  پارسال -> last_year, هفته/ماه پیش|قبل -> last_* ; جاری variants)
DATE_SYNONYMS = {
    'today': ['امروز', 'از صبح تا الان', 'از صبح'],
    'yesterday': ['دیروز', 'روز قبل'],
    'this_week': ['این هفته', 'هفته جاری', 'از اول هفته تا الان', 'از اول هفته'],
    'last_week': ['هفته گذشته', 'هفته قبل', 'هفته پیش', 'هفته پیشین'],
    'this_month': ['این ماه', 'ماه جاری', 'ماه گفتگو'],  # ماه گفتگو never used; harmless
    'last_month': ['ماه گذشته', 'ماه قبل', 'ماه پیش', 'ماه پیشین'],
    'this_year': ['امسال', 'سال جاری', 'سال گفتگو'],
    'last_year': ['سال گذشته', 'پارسال', 'سال قبل', 'سال پیش', 'سال پیشین'],
}

# non-standard date/period phrases accepted because they ARE the 9 documented Stage-A warnings
WARNING_REGISTRY = {
    ('KND-S-0024', 'date_range'), ('KND-S-0025', 'date_range'),
    ('KND-S-0057', 'date_range'), ('KND-S-0062', 'date_range'),
    ('KND-S-0067', 'date_range'), ('KND-S-0166', 'date_range'),
    ('KND-S-0211', 'date_range'), ('KND-S-0223', 'period_a'), ('KND-S-0223', 'period_b'),
}

# canonical_value_exceptions (full registry, by record id) - entity may deviate from text
CANON_EXCEPTION_IDS = {'KND-S-0049', 'KND-S-0107', 'KND-S-0268', 'KND-S-0059', 'KND-S-0073',
                       'KND-S-0052', 'KND-S-0077', 'KND-S-0045', 'KND-S-0078', 'KND-S-0085',
                       'KND-S-0074', 'KND-S-0076'}

HONORIFICS = ('آقای', 'خانم', 'اقای', 'مهندس', 'دکتر', 'سرکار')

# entity types that may be chained anaphorically -> a depends_on slot must NOT carry them
CHAINABLE = {'product_name', 'customer_name', 'invoice_number', 'customer_id', 'phone'}

flags = []
stats = {'records': 0, 'lexicon_hits': {}, 'checks': {'entity_values': 0, 'slots': 0}}


def flag(rec_id, kind, detail):
    flags.append({'id': rec_id, 'kind': kind, 'detail': detail})


def involved(rec):
    """intent labels involved in the record (slots + candidates)."""
    labs = {s['intent'] for s in rec.get('intents', [])}
    labs |= set(rec.get('candidate_intents', []))
    return labs


# ---------------------------------------------------------------- load
recs = [json.loads(l) for l in open(CORPUS, encoding='utf-8') if l.strip()]
ledger = json.load(open(LEDGER, encoding='utf-8'))
stats['records'] = len(recs)

by_id = {}
for r in recs:
    if r['id'] in by_id:
        flag(r['id'], 'duplicate_id', 'id appears twice')
    by_id[r['id']] = r
    if r.get('review_status') != 'seed_needs_review':
        flag(r['id'], 'review_status', 'expected seed_needs_review, got %r' % r.get('review_status'))

norm_text = {r['id']: normalize(r['text']) for r in recs}
seen_texts = {}
for r in recs:
    t = norm_text[r['id']]
    if t in seen_texts:
        flag(r['id'], 'duplicate_text', 'same normalised text as %s' % seen_texts[t])
    seen_texts[t] = r['id']

# ---------------------------------------------------------------- per-record checks
for r in recs:
    rid, tt = r['id'], r['task_type']
    text, nt = r['text'], norm_text[r['id']]
    labs = involved(r)

    # ---- structure
    if tt not in ('single', 'multi', 'ambiguous', 'out_of_scope'):
        flag(rid, 'task_type', tt)
    for s in r.get('intents', []):
        stats['checks']['slots'] += 1
        if s['intent'] not in INTENTS:
            flag(rid, 'intent_whitelist', s['intent'])
        for k, v in (s.get('entities') or {}).items():
            stats['checks']['entity_values'] += 1
            if k not in {'product_name', 'customer_name', 'customer_id', 'phone',
                         'invoice_number', 'date', 'date_range', 'period_a', 'period_b', 'limit'}:
                flag(rid, 'entity_whitelist', k)
            if v in (None, '', []):
                flag(rid, 'empty_entity_value', '%s=%r' % (k, v))
    for c in r.get('candidate_intents', []):
        if c not in INTENTS:
            flag(rid, 'candidate_whitelist', c)

    # ---- NC consistency
    nc = r.get('needs_clarification')
    reason, quest = r.get('clarification_reason'), r.get('clarification_question')
    if nc:
        if not reason or not quest:
            flag(rid, 'nc_missing_fields', 'needs_clarification without reason/question')
        if tt == 'single' and len(r.get('intents', [])) != 1:
            flag(rid, 'nc_single_shape', 'NC single must hold exactly 1 intent slot')
        if tt == 'ambiguous' and len(r.get('candidate_intents', [])) < 2:
            flag(rid, 'nc_ambiguous_shape', 'ambiguous needs >=2 candidates')
        if tt == 'ambiguous' and r.get('intents'):
            flag(rid, 'nc_ambiguous_shape', 'ambiguous must have empty intents')
    else:
        if reason or quest:
            flag(rid, 'nc_fields_without_flag', 'reason/question present while NC=false')
        if tt == 'ambiguous':
            flag(rid, 'ambiguous_needs_nc', 'ambiguous without needs_clarification')

    # ---- OOS shape
    if tt == 'out_of_scope':
        if r.get('intents') or r.get('candidate_intents'):
            flag(rid, 'oos_shape', 'OOS must have empty intents/candidates')
        if r.get('oos_category') not in OOS_CATS:
            flag(rid, 'oos_category', r.get('oos_category'))
    else:
        if 'oos_category' in r:
            flag(rid, 'oos_field_leak', 'oos_category on non-OOS record')

    # ---- depends_on legality
    if tt == 'single':
        for s in r.get('intents', []):
            if s.get('depends_on') is not None:
                flag(rid, 'depends_single', 'single slot with depends_on')
    if tt == 'multi':
        n = len(r.get('intents', []))
        for i, s in enumerate(r.get('intents', [])):
            d = s.get('depends_on')
            if d is None:
                continue
            if not (isinstance(d, int) and 0 <= d < n and d != i):
                flag(rid, 'depends_index', 'slot %d depends_on %r' % (i, d))
            else:
                ent = s.get('entities') or {}
                carried = CHAINABLE & set(ent.keys())
                if carried:
                    flag(rid, 'depends_explicit_entity',
                         'chained slot carries %s (explicit entity => independent per M-0024)' % sorted(carried))

    # ---- entity evidence & digit conventions
    for s in r.get('intents', []):
        for k, v in (s.get('entities') or {}).items():
            if k in ('product_name', 'customer_name'):
                nv = normalize(v)
                if not (contains_phrase(nt, nv) or rid in CANON_EXCEPTION_IDS):
                    # affix-family fallback: value minus one trailing suffix char-run present
                    stem = re.sub(r'(مون|مون|مان|ای|اش|ش|ها|های)$', '', nv.split()[-1])
                    ok = stem and stem in nt and all(w in nt for w in nv.split()[:-1])
                    if not ok:
                        flag(rid, 'name_evidence', '%s=%r not in text and not in exception registry' % (k, v))
                for h in HONORIFICS:
                    if v.startswith(h):
                        flag(rid, 'honorific_in_entity', '%s=%r' % (k, v))
            elif k in ('customer_id', 'invoice_number', 'phone'):
                if not re.fullmatch(r'[0-9]+', str(v)):
                    flag(rid, 'latin_digits', '%s=%r' % (k, v))
                elif not contains_phrase(nt, str(v)):
                    flag(rid, 'id_evidence', '%s=%r not in text' % (k, v))
            elif k == 'limit':
                if not re.fullmatch(r'[0-9]+', str(v)):
                    flag(rid, 'limit_format', v)
                else:
                    lim = int(v)
                    words = [w for w, n in WORD_NUMBERS.items() if n == lim]
                    if not (str(lim) in nt or any(contains_phrase(nt, w) for w in words)):
                        flag(rid, 'limit_evidence', 'limit=%s not evidenced' % v)
            elif k in DATE_FIELDS:
                v = str(v)
                if v in STD_DATES:
                    if not any(contains_phrase(nt, normalize(syn)) for syn in DATE_SYNONYMS[v]):
                        flag(rid, 'date_evidence', '%s=%s lacks synonym evidence' % (k, v))
                elif any(ch.isdigit() for ch in v):
                    toks = normalize(v).split()
                    for tok in toks:
                        if tok.isdigit():
                            if tok not in nt:
                                flag(rid, 'date_evidence', '%s=%s digit %s absent' % (k, v, tok))
                        elif not contains_phrase(nt, tok):
                            flag(rid, 'date_evidence', '%s=%s token %r absent' % (k, v, tok))
                elif (rid, k) in WARNING_REGISTRY:
                    pass  # documented Stage-A warning family
                else:
                    flag(rid, 'date_nonstandard', '%s=%r (not standard, no digit, not in warning registry)' % (k, v))

    # ---- lexicon families (semantic confirmation)
    def has(w):
        return contains_phrase(nt, w)

    fam = []
    if has('حساب') and not has('صورتحساب'):
        fam.append('حساب')
        if tt != 'out_of_scope' and not (labs & {'GET_SALES_REPORT', 'SEARCH_INVOICE'}):
            flag(rid, 'lexicon_حساب', 'text mentions حساب but neither GSR nor SI involved: %s' % sorted(labs))
    if has('صورتحساب'):
        fam.append('صورتحساب')
        if tt != 'out_of_scope' and not (labs & {'GET_LAST_INVOICE', 'SEARCH_INVOICE'}):
            flag(rid, 'lexicon_صورتحساب', 'صورتحساب but no GLI/SI: %s' % sorted(labs))
    if has('گزارش'):
        fam.append('گزارش')
        if tt != 'out_of_scope' and not (labs & {'GET_SALES_REPORT', 'GET_DAILY_SUMMARY'}):
            flag(rid, 'lexicon_گزارش', 'گزارش but neither GSR nor GDS: %s' % sorted(labs))
    if has('خلاصه'):
        fam.append('خلاصه')
        if tt != 'out_of_scope' and not (labs & {'GET_DAILY_SUMMARY'}):
            flag(rid, 'lexicon_خلاصه', 'خلاصه but no GDS: %s' % sorted(labs))
    if has('موجودی'):
        fam.append('موجودی')
        if tt != 'out_of_scope' and not (labs & {'GET_PRODUCT_STOCK', 'GET_LOW_STOCK'}):
            flag(rid, 'lexicon_موجودی', 'موجودی but no GPSK/GLS: %s' % sorted(labs))
    if has('درآمد'):
        fam.append('درآمد')
        if tt != 'out_of_scope' and 'GET_SALES_REPORT' not in labs:
            flag(rid, 'lexicon_درآمد', 'درآمد but no GSR: %s' % sorted(labs))
    if has('سود'):
        fam.append('سود')
        if tt == 'out_of_scope':
            if r.get('oos_category') != 'unsupported_business_feature':
                flag(rid, 'lexicon_سود', 'سود in OOS but category=%s' % r.get('oos_category'))
        else:
            flag(rid, 'lexicon_سود', 'سود in-scope (profit is unsupported): %s' % sorted(labs))
    if has('پرفروش') or has('کمفروش'):  # ZWNJ dropped by normalize
        fam.append('پرفروش/کم‌فروش')
        if tt != 'out_of_scope' and 'GET_TOP_PRODUCTS' not in labs:
            flag(rid, 'lexicon_پرفروش', 'ranking token but no GTP: %s' % sorted(labs))
    if has('فاکتور') or has('فکتور'):
        fam.append('فاکتور')
        if tt != 'out_of_scope' and not (labs & {'GET_LAST_INVOICE', 'SEARCH_INVOICE', 'GET_CUSTOMER_INFO'}):
            flag(rid, 'lexicon_فاکتور', 'فاکتور but no GLI/SI/GCI: %s' % sorted(labs))
    for f in fam:
        stats['lexicon_hits'][f] = stats['lexicon_hits'].get(f, 0) + 1

    # ---- پارسال -> last_year consistency
    if has('پارسال'):
        for s in r.get('intents', []):
            for k in DATE_FIELDS:
                v = (s.get('entities') or {}).get(k)
                if v is not None and str(v) not in ('last_year',):
                    if not any(ch.isdigit() for ch in str(v)) and str(v) not in STD_DATES:
                        pass  # phrase values reviewed separately
                    elif str(v) != 'last_year':
                        flag(rid, 'پارسال_consistency', '%s=%s (expected last_year)' % (k, v))
                elif v is not None and str(v) != 'last_year' and str(v) in STD_DATES:
                    flag(rid, 'پارسال_consistency', '%s=%s (expected last_year)' % (k, v))

# ---------------------------------------------------------------- cross checks vs ledger
per_task = {}
for r in recs:
    per_task[r['task_type']] = per_task.get(r['task_type'], 0) + 1
led = ledger.get('per_task_type_counts', {})
if per_task != led:
    flag('-', 'ledger_mismatch', 'per_task_type_counts ledger=%s actual=%s' % (led, per_task))

# NC coverage per intent (12/12 ratified in batch 19)
nc_intents = set()
for r in recs:
    if r['task_type'] == 'single' and r.get('needs_clarification'):
        nc_intents.add(r['intents'][0]['intent'])
stats['nc_single_intents'] = sorted(nc_intents)

# ---------------------------------------------------------------- report
os.makedirs(os.path.dirname(REPORT), exist_ok=True)
json.dump({'flags': flags, 'stats': stats}, open(REPORT, 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)

print('Stage C semantic pass over %d records' % len(recs))
print('  slots checked      : %d' % stats['checks']['slots'])
print('  entity values      : %d' % stats['checks']['entity_values'])
print('  lexicon family hits: %s' % json.dumps(stats['lexicon_hits'], ensure_ascii=False))
print('  NC single coverage : %d/12 intents -> %s' % (len(nc_intents), ', '.join(
    i.split('_', 1)[1] for i in nc_intents) if nc_intents else '-'))
print('  flags              : %d' % len(flags))
bykind = {}
for f in flags:
    bykind.setdefault(f['kind'], []).append(f)
for kind in sorted(bykind, key=lambda k: -len(bykind[k])):
    print('\n== %s (%d)' % (kind, len(bykind[kind])))
    for f in bykind[kind]:
        print('   %s : %s' % (f['id'], f['detail'][:160]))
print('\nRESULT: %d flags for human review (see %s)' % (len(flags), REPORT))
