#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kandoo Intent Dataset v0.2 — Delivery Audit Runner (re-execution tool).

Re-executes every QC check on the FINAL delivered file and verifies every
number claimed in the mission report. Produces the uniform QC stage reports
(A/B/C/D), the statistics file, the human-review priority list and the master
delivery_audit.json evidence file.

Checks implemented (mirrors the delivery contract):
  1.  structural validation of every record        -> runs validate_batch.py
  2.  record counts + intent distribution          -> in-process recount
  3.  duplicate / missing IDs                      -> in-process recount
  4.  invalid JSON detection                       -> per-line json.loads
  5.  entity-vs-text evidence consistency          -> runs stage_c_semantic_pass.py
  6.  depends_on + slot ordering legality          -> in-process + stage C
  7.  clarification-field consistency              -> in-process + stage C
  8.  ambiguous / out-of-scope record shape        -> in-process + stage A
  9.  exact / near-duplicate sweep                 -> in-process (Stage B logic)
  10. reproduction of final-report statistics      -> in-process recount

Notes on honest reporting:
  - automated checks that PASS are marked PASS;
  - checks requiring human judgement (semantic adjudication of stage-C flags,
    designed-minimal-pair adjudication of near-dup pairs >= 0.75) are marked
    HUMAN_REVIEW_REQUIRED with the evidence listed;
  - every report carries: script name, script sha256, execution timestamp,
    input file + sha256, record count, error/warning counts, details, result.

Usage (from anywhere; paths resolve relative to this file):
    python3 delivery_audit.py

Outputs (into ../reports/):
    qc_stage_a_report.json, qc_stage_b_report.json, qc_stage_c_report.json,
    qc_stage_d_report.json, dataset_statistics.json,
    human_review_priority.json, delivery_audit.json
"""
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from collections import Counter

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
V02_DIR = os.path.dirname(SCRIPT_DIR)
DATASET = os.path.join(V02_DIR, 'kandoo_intent_dataset_v0.2.jsonl')
BATCHES_DIR = os.path.join(V02_DIR, 'batches')
REJECTED_DIR = os.path.join(V02_DIR, 'rejected_drafts')
LEDGER_PATH = os.path.join(V02_DIR, '_progress.json')
REPORTS_DIR = os.path.join(V02_DIR, 'reports')

sys.path.insert(0, SCRIPT_DIR)
from farsi import normalize, similarity  # noqa: E402

INTENTS = {'GET_SALES_REPORT', 'GET_PRODUCT_SALES', 'GET_PRODUCT_STOCK', 'GET_LOW_STOCK',
           'SEARCH_PRODUCT', 'GET_LAST_INVOICE', 'SEARCH_INVOICE', 'GET_CUSTOMER_INFO',
           'SEARCH_CUSTOMER', 'GET_TOP_PRODUCTS', 'GET_SALES_COMPARISON', 'GET_DAILY_SUMMARY'}
CHAINABLE = {'product_name', 'customer_name', 'invoice_number', 'customer_id', 'phone'}
DATE_FIELDS = {'date', 'date_range', 'period_a', 'period_b'}

# documented warning registry (9 warnings, 3 families) — mirrors stage_c_semantic_pass.py
WARNING_REGISTRY_IDS = ['KND-S-0024', 'KND-S-0025', 'KND-S-0057', 'KND-S-0062',
                        'KND-S-0067', 'KND-S-0166', 'KND-S-0211', 'KND-S-0223']
CANON_EXCEPTION_IDS = {'KND-S-0049', 'KND-S-0107', 'KND-S-0268', 'KND-S-0059', 'KND-S-0073',
                       'KND-S-0052', 'KND-S-0077', 'KND-S-0045', 'KND-S-0078', 'KND-S-0085',
                       'KND-S-0074', 'KND-S-0076'}

EXECUTED_AT = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
VERSION = '1.0.0'


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def script_meta(name):
    p = os.path.join(SCRIPT_DIR, name)
    return {'name': name, 'sha256': sha256_of(p), 'version': VERSION,
            'executed_at_utc': EXECUTED_AT}


def load_jsonl(path):
    recs, invalid = [], []
    with open(path, encoding='utf-8') as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                recs.append(json.loads(line))
            except json.JSONDecodeError as exc:
                invalid.append({'line': i, 'error': str(exc)})
    return recs, invalid


def run_stage(script, args=()):
    """Run a sibling QC script, capture console output + exit code."""
    cmd = [sys.executable, os.path.join(SCRIPT_DIR, script)] + list(args)
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    return {'command': ' '.join(os.path.basename(c) if i == 0 else c for i, c in enumerate(cmd)),
            'exit_code': proc.returncode,
            'stdout': proc.stdout, 'stderr': proc.stderr}


# ================================================================ 1. file integrity
def file_integrity():
    out = {'final_file': {
        'path': os.path.relpath(DATASET, V02_DIR),
        'sha256': sha256_of(DATASET),
        'bytes': os.path.getsize(DATASET),
        'utf8_valid': True,  # proven below by reading every line
    }}
    try:
        with open(DATASET, 'rb') as f:
            f.read().decode('utf-8')
    except UnicodeDecodeError as exc:
        out['final_file']['utf8_valid'] = False
        out['final_file']['utf8_error'] = str(exc)

    batch_files = []
    concat_lines = []
    for name in sorted(os.listdir(BATCHES_DIR)):
        if not name.endswith('.jsonl'):
            continue
        p = os.path.join(BATCHES_DIR, name)
        _r, invalid = load_jsonl(p)
        batch_files.append({'path': 'batches/' + name, 'sha256': sha256_of(p),
                            'records': len(_r), 'invalid_json_lines': len(invalid)})
        with open(p, encoding='utf-8') as f:
            concat_lines.extend(l.rstrip('\n') for l in f if l.strip())
    out['batch_files'] = batch_files
    out['batch_concat_record_count'] = len(concat_lines)

    with open(DATASET, encoding='utf-8') as f:
        final_lines = [l.rstrip('\n') for l in f if l.strip()]
    out['final_file']['records'] = len(final_lines)
    out['concat_equals_final_exact_bytes'] = concat_lines == final_lines

    # record-level (order-insensitive id multiset) equivalence as second view
    ids_concat = Counter(json.loads(l)['id'] for l in concat_lines)
    ids_final = Counter(json.loads(l)['id'] for l in final_lines)
    out['concat_equals_final_id_multiset'] = ids_concat == ids_final

    rej = []
    if os.path.isdir(REJECTED_DIR):
        for name in sorted(os.listdir(REJECTED_DIR)):
            p = os.path.join(REJECTED_DIR, name)
            r, _ = load_jsonl(p)
            rej.append({'path': 'rejected_drafts/' + name, 'sha256': sha256_of(p),
                        'records': len(r),
                        'note': 'rejected production draft - NOT part of the final dataset '
                                '(see _progress.json qc_incidents)'})
    out['rejected_drafts'] = rej
    return out


# ================================================================ 2. claims verification
def claims_verification(recs, ledger, stage_a_result, near_dup):
    by_tt = Counter(r['task_type'] for r in recs)
    slots = sum(len(r.get('intents', [])) for r in recs)
    ent_vals = sum(len(s.get('entities') or {}) for r in recs for s in r.get('intents', []))
    used_intents = {s['intent'] for r in recs for s in r.get('intents', [])}
    nc_records = sum(1 for r in recs if r.get('needs_clarification'))

    # human review priority from ledger batch_log
    hr_ids = []
    for b in ledger['batch_log']:
        hr_ids.extend(b.get('human_review_priority', []))
    hr_unique = sorted(set(hr_ids))

    multi = [r for r in recs if r['task_type'] == 'multi']
    slot_hist = Counter(len(r['intents']) for r in multi)
    chained = [r['id'] for r in multi if any(s.get('depends_on') is not None for s in r['intents'])]
    multi_dep = [r['id'] for r in multi
                 if sum(1 for s in r['intents'] if s.get('depends_on') is not None) >= 2]
    repeated = [r['id'] for r in multi
                if len([s['intent'] for s in r['intents']]) != len({s['intent'] for s in r['intents']})]
    multi_nc = [r['id'] for r in multi if r.get('needs_clarification')]

    claims = [
        ('C01', 'total records', 398, len(recs)),
        ('C02', 'single records', 272, by_tt.get('single', 0)),
        ('C03', 'multi records', 53, by_tt.get('multi', 0)),
        ('C04', 'ambiguous records', 23, by_tt.get('ambiguous', 0)),
        ('C05', 'out-of-scope records', 50, by_tt.get('out_of_scope', 0)),
        ('C06', 'unique intents', 12, len(used_intents)),
        ('C07', 'intent slots', 391, slots),
        ('C08', 'entity values', 385, ent_vals),
        ('C09', 'records needing clarification', 49, nc_records),
        ('C10', 'human-review priority records', 144, len(hr_unique)),
        ('C11', 'closed convention decisions', 44,
         len(ledger['pending_for_later_batches']['closed_convention_decisions'])),
        ('C12', 'structural warnings (documented)', 9, stage_a_result['warnings']),
        ('C13', 'near-duplicate pairs >= 0.75', 31, len(near_dup['pairs_ge_075'])),
        ('C14', 'multi records with 2 slots', 43, slot_hist.get(2, 0)),
        ('C15', 'multi records with 3 slots', 8, slot_hist.get(3, 0)),
        ('C16', 'multi records with 4 slots', 1, slot_hist.get(4, 0)),
        ('C17', 'multi records with 5 slots', 1, slot_hist.get(5, 0)),
        ('C18', 'dependency chains (multi records with >=1 depends_on)', 12, len(chained)),
        ('C19', 'multi-dependent records (>=2 depends_on edges)', 3, len(multi_dep)),
        ('C20', 'records with repeated intent + different entities', 19, len(repeated)),
        ('C21', 'multi records carrying needs_clarification', 1, len(multi_nc)),
        ('C22', 'ledger total_samples', 398, ledger['total_samples']),
        ('C23', 'ledger per_task_type_counts matches actual', True,
         dict(ledger['per_task_type_counts']) == dict(by_tt)),
        ('C24', 'ledger per_intent_counts matches actual', True, _per_intent_check(recs, ledger)),
        ('C25', 'ledger id_counters match actual per prefix', True, _id_counter_check(recs, ledger)),
    ]
    table = []
    for cid, desc, claimed, actual in claims:
        table.append({'id': cid, 'claim': desc, 'claimed': claimed, 'actual': actual,
                      'status': 'MATCH' if claimed == actual else 'MISMATCH'})
    return {'claims': table,
            'all_match': all(c['status'] == 'MATCH' for c in table),
            'mismatches': [c for c in table if c['status'] != 'MATCH']}


def _per_intent_check(recs, ledger):
    actual = Counter(s['intent'] for r in recs for s in r.get('intents', []))
    return dict(actual) == dict(ledger['per_intent_counts'])


def _id_counter_check(recs, ledger):
    pref = {'S': 'single', 'M': 'multi', 'A': 'ambiguous', 'O': 'out_of_scope'}
    actual = Counter(r['id'].split('-')[1] for r in recs)
    return all(ledger['id_counters'][v] == actual.get(k, 0) for k, v in pref.items())


# ================================================================ stage A (runner)
def stage_a_report():
    run = run_stage('validate_batch.py', [DATASET])
    out_lines = run['stdout'].splitlines()
    errors, warnings, section = [], [], None
    for line in out_lines:
        if line.startswith('errors'):
            section = 'err'
        elif line.startswith('warnings'):
            section = 'warn'
        elif line.startswith('  ERROR: '):
            errors.append(line.strip()[8:])
        elif line.startswith('  WARN : '):
            warnings.append(line.strip()[8:])
    total = None
    m = re.search(r'total samples\s*:\s*(\d+)', run['stdout'])
    if m:
        total = int(m.group(1))
    rep = {
        'stage': 'A - structural validation',
        'script': script_meta('validate_batch.py'),
        'executed_via': 'delivery_audit.py runner (subprocess)',
        'input_file': {'path': 'kandoo_intent_dataset_v0.2.jsonl', 'sha256': sha256_of(DATASET)},
        'records_checked': total,
        'errors': len(errors),
        'error_details': errors,
        'warnings': len(warnings),
        'warning_details': warnings,
        'result': 'PASS' if run['exit_code'] == 0 and not errors else 'FAIL',
        'note': 'The 9 warnings are the documented intentional phrase-valued '
                'date/period entities (3 families, ratified convention decisions); '
                'they are kept verbatim by design for human review.',
        'rerun_command': 'python3 scripts/validate_batch.py kandoo_intent_dataset_v0.2.jsonl',
        'console_output': run['stdout'],
    }
    return rep


# ================================================================ stage B (dup sweep)
def stage_b_report(recs, ledger, hist_preflight_path=None):
    norm = [normalize(r['text']) for r in recs]
    seen = {}
    exact = []
    for i, nt in enumerate(norm):
        if nt in seen:
            exact.append({'a': recs[seen[nt]]['id'], 'b': recs[i]['id']})
        else:
            seen[nt] = i

    pairs = []
    for i in range(len(recs)):
        for j in range(i + 1, len(recs)):
            s = similarity(norm[i], norm[j])
            if s >= 0.75:
                pairs.append({'similarity': round(s, 3),
                              'a': recs[i]['id'], 'b': recs[j]['id'],
                              'task_type_a': recs[i]['task_type'],
                              'task_type_b': recs[j]['task_type'],
                              'text_a': recs[i]['text'], 'text_b': recs[j]['text']})
    pairs.sort(key=lambda p: -p['similarity'])

    sig = lambda r: (r['task_type'], tuple(sorted(s['intent'] for s in r.get('intents', []))),
                     tuple(sorted(r.get('candidate_intents', []))))
    sigmap = {}
    for i, r in enumerate(recs):
        sigmap.setdefault(sig(r), []).append(i)
    max_same, max_pair = 0.0, None
    for k, idxs in sigmap.items():
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                s = similarity(norm[idxs[a]], norm[idxs[b]])
                if s > max_same:
                    max_same, max_pair = round(s, 3), (recs[idxs[a]]['id'], recs[idxs[b]]['id'])

    ge_090 = [p for p in pairs if p['similarity'] >= 0.90]
    ge_080 = [p for p in pairs if p['similarity'] >= 0.80]

    # classify >=0.75 pairs: different label signatures -> designed minimal pair;
    # same signature -> register/template variant (final adjudication is human)
    def classify(p):
        ia, ib = next(r for r in recs if r['id'] == p['a']), next(r for r in recs if r['id'] == p['b'])
        return 'designed minimal pair (different labels)' if sig(ia) != sig(ib) \
            else 'register/template variant (same labels)'

    historical = {'per_batch_stage_a_from_ledger': [
        {'batch': b['batch'], 'n': b['n'], 'stage_a': b['stage_a']} for b in ledger['batch_log']]}
    if hist_preflight_path and os.path.exists(hist_preflight_path):
        historical['section_preflight_entries'] = json.load(open(hist_preflight_path, encoding='utf-8'))

    rep = {
        'stage': 'B - duplication / near-duplicate sweep (whole frozen file)',
        'script': script_meta('delivery_audit.py'),
        'logic_source': 'scripts/qc.py stage-B thresholds (DROP_SIM=0.90, FLAG_SIM=0.80) '
                        'and scripts/farsi.py normalize()/similarity(); re-implemented in this '
                        'runner for the whole-file re-execution. Historical per-batch preflight '
                        'evidence embedded below.',
        'input_file': {'path': 'kandoo_intent_dataset_v0.2.jsonl', 'sha256': sha256_of(DATASET)},
        'records_checked': len(recs),
        'exact_duplicates': len(exact),
        'exact_duplicate_details': exact,
        'pairs_ge_090': len(ge_090),
        'pairs_ge_090_details': ge_090,
        'pairs_ge_080': len(ge_080),
        'pairs_ge_075': len(pairs),
        'pairs_ge_075_details': [{**p, 'classification': classify(p)} for p in pairs],
        'max_same_signature_similarity': max_same,
        'max_same_signature_pair': list(max_pair) if max_pair else None,
        'automated_result': 'PASS' if not exact and not ge_090 else 'FAIL',
        'automated_pass_criteria': '0 exact duplicates AND 0 pairs with similarity >= 0.90',
        'human_review_note': 'The %d pairs in [0.75, 0.90) are registered as designed minimal '
                             'pairs / register variants per the ratified convention '
                             '(minimal_pairs decision). Their designed status is a documented '
                             'adjudication - HUMAN_REVIEW_REQUIRED for final sign-off.'
                             % len(pairs),
        'historical_evidence': historical,
        'rerun_command': 'python3 scripts/delivery_audit.py  (stage B section) | '
                         'per-batch: python3 scripts/check_near_dup.py <batch_file>',
    }
    return rep


# ================================================================ stage C / D (runners)
def stage_c_report():
    run = run_stage('stage_c_semantic_pass.py')
    raw_path = os.path.join(REPORTS_DIR, 'stage_c_report_raw.json')
    raw = json.load(open(raw_path, encoding='utf-8')) if os.path.exists(raw_path) else None
    rep = {
        'stage': 'C - semantic convention pass (whole file)',
        'script': script_meta('stage_c_semantic_pass.py'),
        'executed_via': 'delivery_audit.py runner (subprocess)',
        'input_file': {'path': 'kandoo_intent_dataset_v0.2.jsonl', 'sha256': sha256_of(DATASET)},
        'records_checked': (raw or {}).get('stats', {}).get('records'),
        'flags': len((raw or {}).get('flags', [])),
        'flag_details': (raw or {}).get('flags', []),
        'stats': (raw or {}).get('stats', {}),
        'automated_result': 'PASS' if run['exit_code'] == 0 else 'FAIL',
        'human_review_note': 'Stage C does not auto-edit records: every flag is queued for human '
                             'review. The %d flags were adjudicated in the consolidation pass '
                             '(documented in _progress.json conventions/stage_c_outcome) as '
                             'by-design patterns with 0 record errors; that adjudication itself '
                             'is a HUMAN decision recorded in the ledger, not an automated PASS.'
                             % len((raw or {}).get('flags', [])),
        'rerun_command': 'python3 scripts/stage_c_semantic_pass.py',
        'console_output': run['stdout'][:8000],
    }
    return rep


def stage_d_report():
    run = run_stage('stage_d_audit.py')
    raw_path = os.path.join(REPORTS_DIR, 'stage_d_report_raw.json')
    raw = json.load(open(raw_path, encoding='utf-8')) if os.path.exists(raw_path) else None
    claims_audit = (raw or {}).get('claims_audit')
    rep = {
        'stage': 'D - independent audit (IDs, warnings, minimal pairs, coverage, ledger claims)',
        'script': script_meta('stage_d_audit.py'),
        'executed_via': 'delivery_audit.py runner (subprocess)',
        'input_file': {'path': 'kandoo_intent_dataset_v0.2.jsonl', 'sha256': sha256_of(DATASET)},
        'records_checked': (raw or {}).get('task_types', {}) and sum((raw or {}).get('task_types', {}).values()),
        'id_audit': (raw or {}).get('id_audit'),
        'warning_registry': (raw or {}).get('warning_registry'),
        'near_dup_sweep': (raw or {}).get('near_dup_sweep'),
        'human_review': {k: v for k, v in ((raw or {}).get('human_review', {}) or {}).items() if k != 'ids'},
        'claims_audit': claims_audit,
        'result': 'PASS' if run['exit_code'] == 0 and claims_audit == 'ALL LEDGER CLAIMS MATCH ACTUAL COUNTS' else 'FAIL',
        'rerun_command': 'python3 scripts/stage_d_audit.py',
        'console_output': run['stdout'][:8000],
    }
    return rep


# ================================================================ multi-intent audit (independent)
def multi_intent_audit(recs):
    multi = [r for r in recs if r['task_type'] == 'multi']
    hist = Counter(len(r['intents']) for r in multi)

    chains, legality_errors, cycle_errors, m0024_violations = [], [], [], []

    def has_cycle(r):
        n = len(r['intents'])
        edges = {i: s.get('depends_on') for i, s in enumerate(r['intents'])}
        for start in range(n):
            seen, cur = set(), start
            while cur is not None:
                if cur in seen:
                    return True
                seen.add(cur)
                cur = edges[cur]
        return False

    for r in multi:
        slots = r['intents']
        dep_idx = [i for i, s in enumerate(slots) if s.get('depends_on') is not None]
        if dep_idx:
            chains.append({
                'id': r['id'],
                'text': r['text'],
                'slots': [{'i': i, 'intent': s['intent'],
                           'depends_on': s.get('depends_on'),
                           'entities': s.get('entities') or {}} for i, s in enumerate(slots)],
            })
        for i, s in enumerate(slots):
            d = s.get('depends_on')
            if d is None:
                continue
            if not isinstance(d, int):
                legality_errors.append({'id': r['id'], 'slot': i, 'error': 'non-integer depends_on %r' % d})
                continue
            if not (0 <= d < len(slots)):
                legality_errors.append({'id': r['id'], 'slot': i, 'error': 'out-of-range index %d' % d})
            elif d >= i:
                legality_errors.append({'id': r['id'], 'slot': i, 'error': 'forward/self reference: slot %d depends on %d (must be a PREVIOUS slot)' % (i, d)})
            else:
                carried = CHAINABLE & set((s.get('entities') or {}).keys())
                if carried:
                    m0024_violations.append({'id': r['id'], 'slot': i,
                                             'error': 'chained slot carries explicit entity %s (M-0024 rule: explicit entity => independent)' % sorted(carried)})
        if has_cycle(r):
            cycle_errors.append({'id': r['id'], 'error': 'circular depends_on chain'})

    repeated = []
    for r in multi:
        labs = [s['intent'] for s in r['intents']]
        if len(labs) != len(set(labs)):
            ent_sig = [json.dumps(s.get('entities') or {}, sort_keys=True, ensure_ascii=False) for s in r['intents']]
            repeated.append({'id': r['id'], 'intents': labs, 'entity_signatures': ent_sig,
                             'distinct_entities': len(set(ent_sig)) == len(ent_sig) and len(set(labs)) < len(labs)})

    multi_nc = [{'id': r['id'], 'text': r['text'],
                 'needs_clarification': r['needs_clarification'],
                 'clarification_reason': r.get('clarification_reason'),
                 'clarification_question': r.get('clarification_question')}
                for r in multi if r.get('needs_clarification')]

    multi_dep = [r['id'] for r in multi
                 if sum(1 for s in r['intents'] if s.get('depends_on') is not None) >= 2]

    return {
        'slot_histogram': {str(k): v for k, v in sorted(hist.items())},
        'two_slot_records': hist.get(2, 0),
        'three_slot_records': hist.get(3, 0),
        'four_slot_records': hist.get(4, 0),
        'five_slot_records': hist.get(5, 0),
        'dependency_chains': {'count': len(chains), 'records': chains},
        'multi_dependent_records': {'count': len(multi_dep), 'ids': multi_dep},
        'repeated_intent_records': {'count': len(repeated), 'records': repeated},
        'multi_plus_nc': {'count': len(multi_nc), 'records': multi_nc},
        'depends_on_legality_errors': legality_errors,
        'depends_on_cycles': cycle_errors,
        'm0024_rule_violations': m0024_violations,
        'result': 'PASS' if not legality_errors and not cycle_errors and not m0024_violations else 'FAIL',
        'pass_criteria': 'every depends_on is an integer index of a PREVIOUS slot (d < i), '
                         'no cycles (guaranteed by d<i but verified by DFS anyway), and no '
                         'chained slot carries an explicit chainable entity (M-0024 rule)',
    }


# ================================================================ statistics
def dataset_statistics(recs, ledger):
    by_tt = Counter(r['task_type'] for r in recs)
    slot_intents = Counter(s['intent'] for r in recs for s in r.get('intents', []))
    ent_types = Counter(k for r in recs for s in r.get('intents', []) for k in (s.get('entities') or {}))
    date_vals = Counter(str(v) for r in recs for s in r.get('intents', [])
                        for k, v in (s.get('entities') or {}).items() if k in DATE_FIELDS and v)
    nc_by_tt = Counter(r['task_type'] for r in recs if r.get('needs_clarification'))
    nc_reasons = Counter(r.get('clarification_reason') for r in recs if r.get('needs_clarification'))
    cand_pairs = Counter(' + '.join(sorted(r['candidate_intents'])) for r in recs if r['task_type'] == 'ambiguous')
    oos_cats = Counter(r['oos_category'] for r in recs if r['task_type'] == 'out_of_scope')
    nc_single = Counter(r['intents'][0]['intent'] for r in recs
                        if r['task_type'] == 'single' and r.get('needs_clarification'))
    registers = Counter()
    for r in recs:
        n = len(r['text'].split())
        registers['very_short_1_3_words'] += n <= 3
        registers['short_4_7_words'] += 4 <= n <= 7
        registers['medium_8_14_words'] += 8 <= n <= 14
        registers['long_15_plus_words'] += n >= 15
    return {
        'generated_at': EXECUTED_AT,
        'source_file': {'path': 'kandoo_intent_dataset_v0.2.jsonl', 'sha256': sha256_of(DATASET)},
        'total_records': len(recs),
        'task_type_counts': dict(by_tt),
        'unique_intents': len(slot_intents),
        'intent_slots_total': sum(slot_intents.values()),
        'slots_per_intent': dict(slot_intents),
        'entity_values_total': sum(ent_types.values()),
        'entity_values_per_type': dict(ent_types),
        'date_value_distribution': dict(date_vals.most_common()),
        'needs_clarification_total': sum(nc_by_tt.values()),
        'needs_clarification_by_task_type': dict(nc_by_tt),
        'clarification_reasons': dict(nc_reasons),
        'nc_single_per_intent': dict(nc_single),
        'ambiguity_candidate_pairs': dict(cand_pairs),
        'oos_categories': dict(oos_cats),
        'text_length_registers': dict(registers),
    }


# ================================================================ human review priority
def human_review_priority(recs, ledger, stage_c_flags, near_dup_pairs):
    hr_ids = []
    per_id_batches = {}
    for b in ledger['batch_log']:
        for rid in b.get('human_review_priority', []):
            hr_ids.append(rid)
            per_id_batches.setdefault(rid, []).append(b['batch'])
    hr_unique = sorted(set(hr_ids))

    multi = {r['id']: r for r in recs if r['task_type'] == 'multi'}
    stage_c_ids = sorted({f['id'] for f in stage_c_flags if f['id'] != '-'})
    near_dup_members = sorted({p['a'] for p in near_dup_pairs} | {p['b'] for p in near_dup_pairs})

    def reasons(rid):
        rs = []
        if rid in WARNING_REGISTRY_IDS:
            rs.append('documented warning-registry record (phrase-valued date/period)')
        if rid in CANON_EXCEPTION_IDS:
            rs.append('canonical_value_exceptions registry (entity deviates from text by ratified rule)')
        if rid in stage_c_ids:
            rs.append('stage-C semantic flag (adjudicated by-design; re-verify at human pass)')
        if rid in near_dup_members:
            rs.append('member of a near-duplicate pair >= 0.75 (designed minimal pair / register variant)')
        r = next((x for x in recs if x['id'] == rid), None)
        if r:
            if r['task_type'] == 'ambiguous':
                rs.append('ambiguous record (clarification design)')
            if r.get('needs_clarification') and r['task_type'] == 'single':
                rs.append('single + needs_clarification (convention-relevant shape)')
            if r['task_type'] == 'multi' and rid in multi:
                labs = [s['intent'] for s in r['intents']]
                if any(s.get('depends_on') is not None for s in r['intents']):
                    rs.append('multi dependency chain')
                if len(labs) != len(set(labs)):
                    rs.append('multi repeated-intent')
                if r.get('needs_clarification'):
                    rs.append('multi + needs_clarification')
            if r['task_type'] == 'out_of_scope':
                rs.append('OOS boundary sample')
        return rs or ['production-time priority mark (see batch_log notes)']

    entries = [{'id': rid, 'flagged_in_batches': sorted(set(per_id_batches[rid])),
                'task_type': next((x['task_type'] for x in recs if x['id'] == rid), None),
                'review_reasons': reasons(rid)} for rid in hr_unique]

    flagged_not_in_list = [rid for rid in stage_c_ids if rid not in set(hr_unique)]

    return {
        'generated_at': EXECUTED_AT,
        'total_unique_records': len(hr_unique),
        'note': 'All 398 records carry review_status=seed_needs_review; this list is the '
                'accumulated production-time PRIORITY list from the 22 batch_log entries. '
                'Every record remains subject to the mandatory human review before v0.3.',
        'records': entries,
        'supplementary_stage_c_flagged_not_in_priority': {
            'ids': flagged_not_in_list,
            'count': len(flagged_not_in_list),
            'note': 'records carrying a stage-C semantic flag that are NOT in the production '
                    'priority list - audit finding; recommend adding them to the human pass'},
    }


# ================================================================ main
def main():
    os.makedirs(REPORTS_DIR, exist_ok=True)
    # NOTE: stage_c/stage_d subprocess runs write their RAW evidence to
    # reports/stage_{c,d}_report_raw.json; this runner wraps them into the
    # uniform reports/qc_stage_{c,d}_report.json files.
    print('Kandoo Intent Dataset v0.2 - delivery audit runner')
    print('executed_at_utc: %s' % EXECUTED_AT)
    print('dataset        : %s' % DATASET)

    recs, invalid_lines = load_jsonl(DATASET)
    ledger = json.load(open(LEDGER_PATH, encoding='utf-8'))
    print('records loaded : %d (invalid JSON lines: %d)' % (len(recs), len(invalid_lines)))

    integ = file_integrity()
    print('[1] file integrity: concat==final bytes: %s | id multiset: %s' % (
        integ['concat_equals_final_exact_bytes'], integ['concat_equals_final_id_multiset']))

    sa = stage_a_report()
    print('[2] stage A: %s (errors=%d, warnings=%d)' % (sa['result'], sa['errors'], sa['warnings']))

    sb = stage_b_report(recs, ledger, hist_preflight_path=os.path.join(
        SCRIPT_DIR, 'historical_stage_b_preflight.json'))
    print('[3] stage B: %s (exact=%d, ge0.90=%d, ge0.75=%d, max same-sig %.3f)' % (
        sb['automated_result'], sb['exact_duplicates'], sb['pairs_ge_090'],
        sb['pairs_ge_075'], sb['max_same_signature_similarity']))

    sc = stage_c_report()
    print('[4] stage C: automated %s (%d flags for human review)' % (sc['automated_result'], sc['flags']))

    sd = stage_d_report()
    print('[5] stage D: %s (%s)' % (sd['result'], sd['claims_audit']))

    near_dup_pairs = [{'a': p['a'], 'b': p['b'], 'similarity': p['similarity']} for p in sb['pairs_ge_075_details']]
    cv = claims_verification(recs, ledger, sa, {'pairs_ge_075': near_dup_pairs})
    print('[6] claims verification: %d/%d MATCH' % (
        sum(1 for c in cv['claims'] if c['status'] == 'MATCH'), len(cv['claims'])))
    for m in cv['mismatches']:
        print('    MISMATCH %s %s: claimed=%r actual=%r' % (m['id'], m['claim'], m['claimed'], m['actual']))

    mi = multi_intent_audit(recs)
    print('[7] multi-intent audit: %s (legality errors=%d, cycles=%d, M-0024 violations=%d)' % (
        mi['result'], len(mi['depends_on_legality_errors']),
        len(mi['depends_on_cycles']), len(mi['m0024_rule_violations'])))

    stats = dataset_statistics(recs, ledger)
    hrp = human_review_priority(recs, ledger, sc['flag_details'], sb['pairs_ge_075_details'])
    print('[8] statistics + human-review list built (%d priority records, %d supplementary)' % (
        hrp['total_unique_records'], hrp['supplementary_stage_c_flagged_not_in_priority']['count']))

    master = {
        'audit_meta': {
            'runner': 'delivery_audit.py', 'runner_version': VERSION,
            'runner_sha256': sha256_of(os.path.abspath(__file__)),
            'executed_at_utc': EXECUTED_AT,
            'dataset_file': 'kandoo_intent_dataset_v0.2.jsonl',
            'dataset_sha256': sha256_of(DATASET),
            'python': sys.version.split()[0],
        },
        'file_integrity': integ,
        'json_validity': {'invalid_json_lines': invalid_lines, 'all_lines_valid_json': not invalid_lines},
        'claims_verification': cv,
        'qc_stage_a': sa,
        'qc_stage_b': sb,
        'qc_stage_c': sc,
        'qc_stage_d': sd,
        'multi_intent_audit': mi,
        'overall_result': 'PASS' if (
            integ['concat_equals_final_exact_bytes'] and not invalid_lines
            and cv['all_match'] and sa['result'] == 'PASS'
            and sb['automated_result'] == 'PASS' and sc['automated_result'] == 'PASS'
            and sd['result'] == 'PASS' and mi['result'] == 'PASS') else 'FAIL',
        'human_review_caveat': 'PASS above covers the automated checks only. Semantic '
                               'adjudication of stage-C flags and designed-pair status of the 31 '
                               'near-duplicate pairs remain HUMAN-REVIEW-REQUIRED (documented '
                               'adjudications live in _progress.json).',
    }

    for name, payload in (('qc_stage_a_report.json', sa), ('qc_stage_b_report.json', sb),
                          ('qc_stage_c_report.json', sc), ('qc_stage_d_report.json', sd),
                          ('dataset_statistics.json', stats),
                          ('human_review_priority.json', hrp),
                          ('delivery_audit.json', master)):
        with open(os.path.join(REPORTS_DIR, name), 'w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=1)
        print('  wrote reports/%s' % name)
    print('OVERALL (automated): %s' % master['overall_result'])


if __name__ == '__main__':
    main()
